#include <stdio.h>
#include "calcul_contour.h"
#include "sequence_point.h"
#include "image.h"
#include <stdlib.h>
Image image_du_contour(Image I, Liste_Point contour)
{
    UINT L = largeur_image(I);
    UINT H = hauteur_image(I);

    Image Ic = creer_image(L, H);

    Cellule_Liste_Point *el = contour.first;

    while (el != NULL)
    {
        int x = (int)el->data.x;
        int y = (int)el->data.y;

        /* on colore le pixel correspondant */
        set_pixel_image(Ic, x + 1, y + 1, NOIR);

        el = el->suiv;
    }

    return Ic;
}

int main(int argc, char *argv[])
{
    if(argc != 2) {
        printf("Usage: %s <image_file.pbm>\n", argv[0]);
        return 1;
    }
    
    Image img = lire_fichier_image(argv[1]);
    
    
    Liste_Point contour = calcul_contour(img);
    Image Ic = image_du_contour(img, contour);

    sauver_image_pbm(Ic, "contour.pbm");
    ecrire_contour(contour);
    supprimer_liste_Point(contour);
    supprimer_image(&img);
    return 0;
}