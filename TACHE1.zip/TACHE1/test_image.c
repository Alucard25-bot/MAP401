#include <stdio.h>
#include <stdlib.h>
#include "image.h"

int main(int argc, char *argv[]) {
    Image img, neg_img;

    if (argc != 2) {
        printf("Usage: %s <fichier_image.pbm>\n", argv[0]);
        return 1;
    }

    // Lire l'image depuis le fichier
    printf("Lecture de l'image %s...\n", argv[1]);
    img = lire_fichier_image(argv[1]);

    printf("Image lue: %dx%d pixels\n", largeur_image(img), hauteur_image(img));

    // Afficher l'image originale
    printf("\nImage originale:\n");
    ecrire_image(img);

    // Créer l'image négative
    printf("\nCréation de l'image négative...\n");
    neg_img = negatif_image(img);

    printf("Image négative créée: %dx%d pixels\n", largeur_image(neg_img), hauteur_image(neg_img));

    // Afficher l'image négative
    printf("\nImage négative:\n");
    ecrire_image(neg_img);

    // Libérer la mémoire
    supprimer_image(&neg_img);
    supprimer_image(&img);

    printf("\nTest terminé avec succès!\n");
    return 0;
}